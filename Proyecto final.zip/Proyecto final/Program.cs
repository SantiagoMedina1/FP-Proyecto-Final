﻿namespace Proyecto_final
{
    // ====== Arreglos globales ======
    const int MAX_HABITACIONES = 20;
    int[] numeroHabitacion = new int[MAX_HABITACIONES];
    string[] tipoHabitacion = new string[MAX_HABITACIONES];
    double[] precioPorNoche = new double[MAX_HABITACIONES];
    bool[] habitacionDisponible = new bool[MAX_HABITACIONES];
    int cantidadHabitaciones = 0;

    // ====== Función: Mostrar menú principal ======
    void MenuPrincipal()
    {
        int opcion = 0;

        while (opcion != 4)
        {
            Console.WriteLine("\n===== MENÚ PRINCIPAL =====");
            Console.WriteLine("1. Gestión de habitaciones");
            Console.WriteLine("2. Gestión de huéspedes");
            Console.WriteLine("3. Gestión de reservas");
            Console.WriteLine("4. Salir");
            Console.Write("Seleccione una opción: ");
            opcion = int.Parse(Console.ReadLine());

            if (opcion == 1)
            {
                GestionHabitaciones();
            }
            else if (opcion == 2)
            {
                Console.WriteLine("Gestión de huéspedes (en construcción)");
            }
            else if (opcion == 3)
            {
                Console.WriteLine("Gestión de reservas (en construcción)");
            }
            else if (opcion == 4)
            {
                Console.WriteLine("Saliendo del programa...");
            }
            else
            {
                Console.WriteLine("⚠️ Opción inválida. Intente de nuevo.");
            }
        }
    }

    // ====== Función: Submenú de gestión de habitaciones ======
    void GestionHabitaciones()
    {
        int opcion = 0;

        while (opcion != 5)
        {
            Console.WriteLine("\n--- GESTIÓN DE HABITACIONES ---");
            Console.WriteLine("1. Registrar una nueva habitación");
            Console.WriteLine("2. Ver lista de habitaciones registradas");
            Console.WriteLine("3. Editar información de una habitación");
            Console.WriteLine("4. Ver disponibilidad de habitaciones");
            Console.WriteLine("5. Volver al menú principal");
            Console.Write("Seleccione una opción: ");
            opcion = int.Parse(Console.ReadLine());

            if (opcion == 1)
            {
                RegistrarHabitacion();
            }
            else if (opcion == 2)
            {
                VerListaHabitaciones();
            }
            else if (opcion == 3)
            {
                EditarInformacionHabitacion();
            }
            else if (opcion == 4)
            {
                MostrarDisponibilidadHabitaciones();
            }
            else if (opcion == 5)
            {
                Console.WriteLine("Volviendo al menú principal...");
            }
            else
            {
                Console.WriteLine("⚠️ Opción inválida. Intente de nuevo.");
            }
        }
    }

    // ====== Función: Registrar habitación ======
    void RegistrarHabitacion()
    {
        if (cantidadHabitaciones >= MAX_HABITACIONES)
        {
            Console.WriteLine("No se pueden registrar más habitaciones.");
            return;
        }

        Console.Write("Ingrese el número de la habitación: ");
        int numero = int.Parse(Console.ReadLine());

        Console.Write("Ingrese el tipo de habitación (Sencilla / Doble / Suite): ");
        string tipo = Console.ReadLine();

        Console.Write("Ingrese el precio por noche: ");
        double precio = double.Parse(Console.ReadLine());

        numeroHabitacion[cantidadHabitaciones] = numero;
        tipoHabitacion[cantidadHabitaciones] = tipo;
        precioPorNoche[cantidadHabitaciones] = precio;
        habitacionDisponible[cantidadHabitaciones] = true;
        cantidadHabitaciones++;

        Console.WriteLine("✅ Habitación registrada correctamente.");
    }

    // ====== Función: Ver lista de habitaciones ======
    void VerListaHabitaciones()
    {
        if (cantidadHabitaciones == 0)
        {
            Console.WriteLine("No hay habitaciones registradas.");
            return;
        }

        Console.WriteLine("\n--- LISTA DE HABITACIONES ---");
        for (int i = 0; i < cantidadHabitaciones; i++)
        {
            Console.WriteLine($"N°: {numeroHabitacion[i]} | Tipo: {tipoHabitacion[i]} | Precio: ${precioPorNoche[i]} | Disponible: {habitacionDisponible[i]}");
        }
    }

    // ====== Función: Editar información de habitación ======
    void EditarInformacionHabitacion()
    {
        Console.Write("Ingrese el número de la habitación que desea editar: ");
        int numeroBuscado = int.Parse(Console.ReadLine());
        int indice = -1;

        for (int i = 0; i < cantidadHabitaciones; i++)
        {
            if (numeroHabitacion[i] == numeroBuscado)
            {
                indice = i;
                break;
            }
        }

        if (indice == -1)
        {
            Console.WriteLine("⚠️ Habitación no encontrada.");
            return;
        }

        Console.Write("Nuevo tipo de habitación: ");
        tipoHabitacion[indice] = Console.ReadLine();

        Console.Write("Nuevo precio por noche: ");
        precioPorNoche[indice] = double.Parse(Console.ReadLine());

        Console.WriteLine("✅ Información actualizada correctamente.");
    }

    // ====== Función: Ver disponibilidad de habitaciones ======
    void MostrarDisponibilidadHabitaciones()
    {
        if (cantidadHabitaciones == 0)
        {
            Console.WriteLine("No hay habitaciones registradas.");
            return;
        }

        Console.WriteLine("\n--- DISPONIBILIDAD DE HABITACIONES ---");
        for (int i = 0; i < cantidadHabitaciones; i++)
        {
            string estado = habitacionDisponible[i] ? "Disponible" : "Ocupada";
            Console.WriteLine($"Hab. {numeroHabitacion[i]} - {estado}");
        }
    }

    // ====== INICIO DEL PROGRAMA ======
    MenuPrincipal();
